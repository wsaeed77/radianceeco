<?php

namespace App\Enums;

enum ActivityType: string
{
    case NOTE = 'note';
    case STATUS_CHANGE = 'status_change';
    case STAGE_CHANGE = 'stage_change';
    case FILE_UPLOAD = 'file_upload';
    case SURVEY = 'survey';
    case INSTALL_BOOKED = 'install_booked';
    case INSTALL_COMPLETED = 'install_completed';
}