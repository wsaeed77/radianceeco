<?php

namespace App\Http\Controllers;

use App\Enums\ActivityType;
use App\Enums\DocumentKind;
use App\Models\Activity;
use App\Models\Document;
use App\Models\Lead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class DocumentViewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the form for uploading a new document to a lead.
     */
    public function createForLead($leadId)
    {
        $lead = Lead::findOrFail($leadId);
        $documentKinds = DocumentKind::cases();
        
        return view('documents.create', compact('lead', 'documentKinds'));
    }

    /**
     * Show the form for uploading a new document to an activity.
     */
    public function createForActivity($leadId, $activityId)
    {
        $lead = Lead::findOrFail($leadId);
        $activity = Activity::findOrFail($activityId);
        $documentKinds = DocumentKind::cases();
        
        return view('documents.create', compact('lead', 'activity', 'documentKinds'));
    }

    /**
     * Store a newly uploaded document for a lead.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'lead_id' => 'required|string|exists:leads,id',
            'activity_id' => 'nullable|string|exists:activities,id',
            'kind' => 'required|string',
            'document' => 'required|file|max:10240', // 10MB max
        ]);
        
        $lead = Lead::findOrFail($validated['lead_id']);
        
        // Check if activity exists and belongs to the lead
        $activity = null;
        if (!empty($validated['activity_id'])) {
            $activity = Activity::where('id', $validated['activity_id'])
                                ->where('lead_id', $lead->id)
                                ->firstOrFail();
        }
        
        // Validate document kind
        try {
            $kind = DocumentKind::from($validated['kind']);
        } catch (\ValueError $e) {
            return back()->withErrors(['kind' => 'Invalid document type selected.']);
        }
        
        $file = $request->file('document');
        $originalName = $file->getClientOriginalName();
        $fileName = Str::slug(pathinfo($originalName, PATHINFO_FILENAME)) . '-' . Str::random(8) . '.' . $file->getClientOriginalExtension();
        
        // Define the storage path
        $path = "documents/{$lead->id}/{$kind->value}/{$fileName}";
        
        // Store the file
        $stored = Storage::disk('public')->put($path, file_get_contents($file));
        
        if (!$stored) {
            return back()->withErrors(['document' => 'Failed to upload document.']);
        }
        
        // Create document record
        $document = Document::create([
            'lead_id' => $lead->id,
            'activity_id' => $activity ? $activity->id : null,
            'kind' => $kind->value,
            'name' => $originalName,
            'disk' => 'public',
            'path' => $path,
            'size_bytes' => $file->getSize(),
            'uploaded_by' => Auth::id(),
            'uploaded_at' => now(),
        ]);
        
        // Create activity record if not already tied to an activity
        if (!$activity) {
            $activity = Activity::create([
                'lead_id' => $lead->id,
                'user_id' => Auth::id(),
                'type' => ActivityType::FILE_UPLOAD,
                'description' => 'Uploaded document: ' . $originalName,
                'message' => 'Document uploaded: ' . $originalName . ' (' . $kind->name . ')',
                'created_by' => Auth::id(),
            ]);
        }
        
        return redirect()->route('leads.show', $lead->id)
            ->with('success', 'Document uploaded successfully.');
    }

    /**
     * Download a document.
     */
    public function download($id)
    {
        $document = Document::findOrFail($id);
        
        if (Storage::disk($document->disk)->exists($document->path)) {
            return Storage::disk($document->disk)->download(
                $document->path,
                $document->name,
                ['Content-Type' => Storage::disk($document->disk)->mimeType($document->path)]
            );
        }
        
        return back()->withErrors(['error' => 'Document not found on storage.']);
    }

    /**
     * Delete a document.
     */
    public function destroy($id)
    {
        $document = Document::findOrFail($id);
        $lead = $document->lead;
        
        // Delete file from storage
        if (Storage::disk($document->disk)->exists($document->path)) {
            Storage::disk($document->disk)->delete($document->path);
        }
        
        // Delete document record
        $document->delete();
        
        return redirect()->route('leads.show', $lead->id)
            ->with('success', 'Document deleted successfully.');
    }
}