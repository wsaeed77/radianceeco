<?php

namespace App\Http\Controllers;

use App\Enums\LeadStage;
use App\Enums\LeadStatus;
use App\Models\Lead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        // Get lead counts by status
        $statusCounts = Lead::select('status', DB::raw('count(*) as count'))
            ->groupBy('status')
            ->get()
            ->mapWithKeys(function ($item) {
                return [$item->status->value => $item->count];
            })
            ->toArray();
        
        // Get lead counts by stage
        $stageCounts = Lead::select('stage', DB::raw('count(*) as count'))
            ->groupBy('stage')
            ->get()
            ->mapWithKeys(function ($item) {
                return [$item->stage->value => $item->count];
            })
            ->toArray();
        
        // Get total leads
        $totalLeads = Lead::count();
        
        // Get recent leads
        $recentLeads = Lead::latest()->take(5)->get();
        
        return view('dashboard', compact('statusCounts', 'stageCounts', 'totalLeads', 'recentLeads'));
    }
}