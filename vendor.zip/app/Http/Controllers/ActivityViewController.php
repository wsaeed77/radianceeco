<?php

namespace App\Http\Controllers;

use App\Enums\ActivityType;
use App\Models\Activity;
use App\Models\Lead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ActivityViewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the form for creating a new activity for a lead.
     */
    public function create($leadId)
    {
        $lead = Lead::findOrFail($leadId);
        $activityTypes = ActivityType::cases();
        
        return view('activities.create', compact('lead', 'activityTypes'));
    }

    /**
     * Store a newly created activity.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'lead_id' => 'required|string|exists:leads,id',
            'type' => 'required|string',
            'description' => 'required|string|max:255',
            'message' => 'nullable|string',
        ]);
        
        $lead = Lead::findOrFail($validated['lead_id']);
        
        // Validate activity type
        try {
            $type = ActivityType::from($validated['type']);
        } catch (\ValueError $e) {
            return back()->withErrors(['type' => 'Invalid activity type selected.']);
        }
        
        // Create activity record
        $activity = Activity::create([
            'lead_id' => $lead->id,
            'user_id' => Auth::id(),
            'type' => $type->value,
            'description' => $validated['description'],
            'message' => $validated['message'] ?? null,
            'created_by' => Auth::id(),
        ]);
        
        return redirect()->route('leads.show', $lead->id)
            ->with('success', 'Activity added successfully.')
            ->with('current_tab', 'activities');
    }

    /**
     * Show the form for editing the specified activity.
     */
    public function edit($id)
    {
        $activity = Activity::with('lead')->findOrFail($id);
        $activityTypes = ActivityType::cases();
        
        return view('activities.edit', compact('activity', 'activityTypes'));
    }

    /**
     * Update the specified activity.
     */
    public function update(Request $request, $id)
    {
        $activity = Activity::findOrFail($id);
        
        $validated = $request->validate([
            'type' => 'required|string',
            'description' => 'required|string|max:255',
            'message' => 'nullable|string',
        ]);
        
        // Validate activity type
        try {
            $type = ActivityType::from($validated['type']);
        } catch (\ValueError $e) {
            return back()->withErrors(['type' => 'Invalid activity type selected.']);
        }
        
        // Update activity
        $activity->update([
            'type' => $type->value,
            'description' => $validated['description'],
            'message' => $validated['message'] ?? null,
        ]);
        
        return redirect()->route('leads.show', $activity->lead_id)
            ->with('success', 'Activity updated successfully.')
            ->with('current_tab', 'activities');
    }

    /**
     * Remove the specified activity.
     */
    public function destroy($id)
    {
        $activity = Activity::findOrFail($id);
        $leadId = $activity->lead_id;
        
        // Delete activity
        $activity->delete();
        
        return redirect()->route('leads.show', $leadId)
            ->with('success', 'Activity deleted successfully.')
            ->with('current_tab', 'activities');
    }
}