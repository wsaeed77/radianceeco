<?php

namespace App\Http\Controllers;

use App\Enums\LeadStage;
use App\Enums\LeadStatus;
use App\Models\Lead;
use App\Models\Activity;
use App\Enums\ActivityType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LeadViewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(Request $request)
    {
        // Filter by status if provided
        $query = Lead::query();
        
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }
        
        if ($request->has('stage')) {
            $query->where('stage', $request->stage);
        }
        
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('first_name', 'like', "%{$search}%")
                  ->orWhere('last_name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }
        
        // Get leads with pagination
        $leads = $query->orderBy('created_at', 'desc')->paginate(10);
        
        // Get all statuses and stages for filters
        $statuses = LeadStatus::cases();
        $stages = LeadStage::cases();
        
        return view('leads.index', compact('leads', 'statuses', 'stages'));
    }
    
    public function show($id)
    {
        $lead = Lead::with(['activities.user', 'stageHistories.user', 'documents'])->findOrFail($id);
        return view('leads.show', compact('lead'));
    }
    
    public function create()
    {
        // Check if user has permissions
        if (!Auth::user()->hasPermissionTo('lead.create')) {
            return redirect()->route('leads.index')
                ->with('error', 'You do not have permission to create leads.');
        }
        
        $statuses = LeadStatus::cases();
        $stages = LeadStage::cases();
        $agents = \App\Models\User::role('agent')->orderBy('name')->get();
        
        return view('leads.create', compact('statuses', 'stages', 'agents'));
    }
    
    public function store(Request $request)
    {
        // Check if user has permissions
        if (!Auth::user()->hasPermissionTo('lead.create')) {
            return redirect()->route('leads.index')
                ->with('error', 'You do not have permission to create leads.');
        }
        
        // Validate the request
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'address_line_1' => 'nullable|string|max:255',
            'address_line_2' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'assigned_to' => 'nullable|string|max:50',
            'zip_code' => 'nullable|string|max:20',
            'status' => 'required|string',
            'stage' => 'required|string',
            'source' => 'nullable|string|max:255',
            'source_details' => 'nullable|string',
            'notes' => 'nullable|string',
            'agent_id' => 'nullable|exists:users,id',
            'grant_type' => 'nullable|string|max:50',
            
            // Eligibility Details
            'occupancy_type' => 'nullable|string|max:255',
            'possible_grant_types' => 'nullable|string|max:255',
            'benefit_type' => 'nullable|string|max:255',
            'poa_info' => 'nullable|string',
            'epc_rating' => 'nullable|string|max:10',
            'epc_details' => 'nullable|string',
            'gas_safe_info' => 'nullable|string|max:255',
            'council_tax_band' => 'nullable|string|max:10',
            'eligibility_client_dob' => 'nullable|date',
            
            // Data Match Fields
            'benefit_holder_name' => 'nullable|string|max:255',
            'benefit_holder_dob' => 'nullable|date',
            'data_match_status' => 'nullable|string|max:50',
            'data_match_remarks' => 'nullable|string',
        ]);
        
        // Process phone numbers
        if ($request->has('multi_phone_labels') && $request->has('multi_phone_numbers')) {
            $labels = $request->multi_phone_labels;
            $numbers = $request->multi_phone_numbers;
            $phoneData = [];
            
            for ($i = 0; $i < count($labels); $i++) {
                if (!empty($numbers[$i])) {
                    $phoneData[] = [
                        'label' => $labels[$i] ?? 'Phone ' . ($i + 1),
                        'number' => $numbers[$i]
                    ];
                }
            }
            
            $validated['multi_phone_numbers'] = $phoneData;
        }
        
        // Create the lead
        $lead = Lead::create($validated);
        
        // Create an activity log
        Activity::create([
            'lead_id' => $lead->id,
            'user_id' => Auth::id(),
            'type' => ActivityType::NOTE->value,
            'description' => 'Lead created',
        ]);
        
        return redirect()->route('leads.show', $lead->id)
            ->with('success', 'Lead created successfully!');
    }
    
    public function edit($id)
    {
        // Check if user has permissions
        if (!Auth::user()->hasPermissionTo('lead.edit')) {
            return redirect()->route('leads.index')
                ->with('error', 'You do not have permission to edit leads.');
        }
        
        $lead = Lead::findOrFail($id);
        $statuses = LeadStatus::cases();
        $stages = LeadStage::cases();
        $agents = \App\Models\User::role('agent')->orderBy('name')->get();
        
        return view('leads.edit', compact('lead', 'statuses', 'stages', 'agents'));
    }
    
    public function update(Request $request, $id)
    {
        // Check if user has permissions
        if (!Auth::user()->hasPermissionTo('lead.edit')) {
            return redirect()->route('leads.index')
                ->with('error', 'You do not have permission to update leads.');
        }
        
        $lead = Lead::findOrFail($id);
        
        // Validate the request
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
            'address_line_1' => 'nullable|string|max:255',
            'address_line_2' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'assigned_to' => 'nullable|string|max:50',
            'zip_code' => 'nullable|string|max:20',
            'status' => 'required|string',
            'stage' => 'required|string',
            'source' => 'nullable|string|max:255',
            'agent_id' => 'nullable|exists:users,id',
            'source_details' => 'nullable|string',
            'notes' => 'nullable|string',
            'grant_type' => 'nullable|string|max:50',
            
            // Eligibility Details
            'occupancy_type' => 'nullable|string|max:255',
            'possible_grant_types' => 'nullable|string|max:255',
            'benefit_type' => 'nullable|string|max:255',
            'poa_info' => 'nullable|string',
            'epc_rating' => 'nullable|string|max:10',
            'epc_details' => 'nullable|string',
            'gas_safe_info' => 'nullable|string|max:255',
            'council_tax_band' => 'nullable|string|max:10',
            'eligibility_client_dob' => 'nullable|date',
            
            // Data Match Fields
            'benefit_holder_name' => 'nullable|string|max:255',
            'benefit_holder_dob' => 'nullable|date',
            'data_match_status' => 'nullable|string|max:50',
            'data_match_remarks' => 'nullable|string',
        ]);
        
        // Process phone numbers
        if ($request->has('multi_phone_labels') && $request->has('multi_phone_numbers')) {
            $labels = $request->multi_phone_labels;
            $numbers = $request->multi_phone_numbers;
            $phoneData = [];
            
            for ($i = 0; $i < count($labels); $i++) {
                if (!empty($numbers[$i])) {
                    $phoneData[] = [
                        'label' => $labels[$i] ?? 'Phone ' . ($i + 1),
                        'number' => $numbers[$i]
                    ];
                }
            }
            
            $validated['multi_phone_numbers'] = $phoneData;
        }
        
        // Check if status has changed
        $statusChanged = $lead->status->value !== $validated['status'];
        $stageChanged = $lead->stage->value !== $validated['stage'];
        $oldStatus = $lead->status->name;
        $oldStage = $lead->stage->name;
        
        // Update the lead
        $lead->update($validated);
        
        // Create an activity log for status change
        if ($statusChanged) {
            // Get the new status name after update
            $newStatusName = LeadStatus::tryFrom($validated['status'])->name;
            
            Activity::create([
                'lead_id' => $lead->id,
                'user_id' => Auth::id(),
                'type' => ActivityType::STATUS_CHANGE->value,
                'description' => 'Status changed from ' . $oldStatus . ' to ' . $newStatusName,
            ]);
        }
        
        // Create a stage history log for stage change
        if ($stageChanged) {
            $lead->stageHistories()->create([
                'previous_stage' => $lead->getOriginal('stage'),
                'new_stage' => $validated['stage'],
                'user_id' => Auth::id(),
                'notes' => 'Stage updated through edit form',
            ]);
        }
        
        return redirect()->route('leads.show', $lead->id)
            ->with('success', 'Lead updated successfully!');
    }
}
