

<?php $__env->startSection('styles'); ?>
<style>
    .status-text, .address-text {
        display: inline-block;
        max-width: 200px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        vertical-align: middle;
    }
    
    .address-text {
        max-width: 230px; /* Give address a bit more room */
    }
    
    .btn-icon {
        background: none;
        border: none;
        padding: 0.25rem 0.5rem;
        font-size: 1rem;
        transition: transform 0.2s;
    }
    
    .btn-icon:hover {
        transform: scale(1.2);
    }
    
    .action-buttons {
        display: flex;
        justify-content: center;
        gap: 0.75rem;
    }
    
    /* Make table more responsive */
    @media (max-width: 768px) {
        .table-responsive {
            font-size: 0.9rem;
        }
        
        .status-text {
            max-width: 120px;
        }
        
        .address-text {
            max-width: 150px;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><?php echo e(__('Leads')); ?></span>
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.create')): ?>
                            <a href="<?php echo e(route('leads.create')); ?>" class="btn btn-sm btn-success me-2">Add New Lead</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-secondary">Back to Dashboard</a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Search and Filter Form -->
                    <form method="GET" action="<?php echo e(route('leads.index')); ?>" class="mb-4">
                        <div class="row">
                            <div class="col-md-4 mb-2">
                                <input type="text" name="search" class="form-control" placeholder="Search by name, email or phone" value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-2 mb-2">
                                <select name="status" class="form-control">
                                    <option value="">-- Select Status --</option>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status->value); ?>" <?php echo e(request('status') == $status->value ? 'selected' : ''); ?>>
                                            <?php echo e($status->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2 mb-2">
                                <select name="stage" class="form-control">
                                    <option value="">-- Select Team --</option>
                                    <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($team->value); ?>" <?php echo e(request('stage') == $team->value ? 'selected' : ''); ?>>
                                            <?php echo e($team->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-2">
                                <button type="submit" class="btn btn-primary me-2">Filter</button>
                                <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-secondary">Clear</a>
                            </div>
                        </div>
                    </form>

                    <!-- Leads Table -->
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Team</th>
                                    <th>Created</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($lead->first_name); ?> <?php echo e($lead->last_name); ?></td>
                                        <td>
                                            <span class="address-text">
                                                <?php if($lead->address_line): ?>
                                                    <?php echo e($lead->address_line); ?>

                                                <?php elseif($lead->house_number || $lead->street_name || $lead->city || $lead->postcode): ?>
                                                    <?php echo e($lead->house_number); ?> <?php echo e($lead->street_name); ?><?php echo e($lead->city ? ', '.$lead->city : ''); ?><?php echo e($lead->postcode ? ', '.$lead->postcode : ''); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td><?php echo e($lead->phone); ?></td>
                                        <td>
                                            <span class="status-text">
                                                <?php echo e($lead->status->name); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($lead->stage->name); ?></td>
                                        <td><?php echo e($lead->created_at->format('M d, Y')); ?></td>
                                        <td class="text-center">
                                            <div class="action-buttons">
                                                <a href="<?php echo e(route('leads.show', $lead->id)); ?>" class="btn btn-sm btn-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="View Lead">
                                                    <i class="fas fa-eye text-info"></i>
                                                </a>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                                                    <a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="btn btn-sm btn-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Lead">
                                                        <i class="fas fa-edit text-primary"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No leads found matching your criteria.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($leads->appends(request()->query())->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mamp\radiance\resources\views/leads/index.blade.php ENDPATH**/ ?>