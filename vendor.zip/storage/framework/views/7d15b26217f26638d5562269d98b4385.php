

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><?php echo e(__('Lead Details')); ?></span>
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                            <a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="btn btn-sm btn-primary me-2">Edit Lead</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-sm btn-secondary me-2">Back to Leads</a>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-secondary">Dashboard</a>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <!-- Lead Information -->
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-header bg-primary text-white">
                                    Lead Information
                                </div>
                                <div class="card-body">
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Name:</div>
                                        <div class="col-md-8"><?php echo e($lead->first_name); ?> <?php echo e($lead->last_name); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Email:</div>
                                        <div class="col-md-8"><?php echo e($lead->email); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Phone:</div>
                                        <div class="col-md-8"><?php echo e($lead->phone); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Status:</div>
                                        <div class="col-md-8"><?php echo e($lead->status->name); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Team:</div>
                                        <div class="col-md-8"><?php echo e($lead->stage->name); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Address:</div>
                                        <div class="col-md-8">
                                            <?php echo e($lead->address_line_1); ?><br>
                                            <?php if($lead->address_line_2): ?>
                                                <?php echo e($lead->address_line_2); ?><br>
                                            <?php endif; ?>
                                            <?php echo e($lead->city); ?>, <?php echo e($lead->assigned_to); ?> <?php echo e($lead->zip_code); ?>

                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Created:</div>
                                        <div class="col-md-8"><?php echo e($lead->created_at->format('M d, Y H:i:s')); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Last Updated:</div>
                                        <div class="col-md-8"><?php echo e($lead->updated_at->format('M d, Y H:i:s')); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Information -->
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-header bg-info text-white">
                                    Additional Information
                                </div>
                                <div class="card-body">
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Source:</div>
                                        <div class="col-md-8"><?php echo e($lead->source ?? 'N/A'); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Source Details:</div>
                                        <div class="col-md-8"><?php echo e($lead->source_details ?? 'N/A'); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Grant Type:</div>
                                        <div class="col-md-8"><?php echo e($lead->grant_type ?? 'N/A'); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Is Duplicate:</div>
                                        <div class="col-md-8"><?php echo e($lead->is_duplicate ? 'Yes' : 'No'); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Is Complete:</div>
                                        <div class="col-md-8"><?php echo e($lead->is_complete ? 'Yes' : 'No'); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Notes:</div>
                                        <div class="col-md-8"><?php echo e($lead->notes ?? 'No notes available'); ?></div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col-md-4 fw-bold">Assigned Agent:</div>
                                        <div class="col-md-8"><?php echo e($lead->agent_id && $lead->assignedAgent ? $lead->assignedAgent->name : 'Not Assigned'); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Data Match Section -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-purple text-white d-flex justify-content-between align-items-center">
                                    <span><i class="fas fa-database me-2"></i> Data Match</span>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Benefit Holder Name:</div>
                                                <div class="col-md-7"><?php echo e($lead->benefit_holder_name ?? 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Benefit Holder DOB:</div>
                                                <div class="col-md-7"><?php echo e($lead->benefit_holder_dob ? $lead->benefit_holder_dob->format('d/m/Y') : 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Data Match Status:</div>
                                                <div class="col-md-7">
                                                    <?php if($lead->data_match_status): ?>
                                                        <span class="badge bg-<?php echo e($lead->data_match_status == 'Matched' ? 'success' : (
                                                            $lead->data_match_status == 'Pending' ? 'warning' : (
                                                            $lead->data_match_status == 'Sent' ? 'info' : (
                                                            $lead->data_match_status == 'Unmatched' ? 'danger' : 'secondary')))); ?>">
                                                            <?php echo e($lead->data_match_status); ?>

                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not specified</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Phone Numbers:</div>
                                                <div class="col-md-7">
                                                    <?php if($lead->multi_phone_numbers && count($lead->multi_phone_numbers) > 0): ?>
                                                        <ul class="list-unstyled mb-0">
                                                            <?php $__currentLoopData = $lead->multi_phone_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><strong><?php echo e($phone['label'] ?? 'Phone'); ?>:</strong> <?php echo e($phone['number']); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    <?php else: ?>
                                                        <span class="text-muted">No phone numbers added</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row mt-3">
                                        <div class="col-12">
                                            <div class="card bg-light">
                                                <div class="card-body pb-1">
                                                    <div class="row mb-2">
                                                        <div class="col-md-3 fw-bold">Data Match Remarks:</div>
                                                        <div class="col-md-9"><?php echo e($lead->data_match_remarks ?? 'Not specified'); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Eligibility Details -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                    <span><i class="fas fa-check-circle me-2"></i> Eligibility Details</span>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Occupancy Type:</div>
                                                <div class="col-md-7">
                                                    <?php if($lead->occupancy_type): ?>
                                                        <span class="badge bg-<?php echo e($lead->occupancy_type == 'owner' ? 'primary' : 'info'); ?>">
                                                            <?php echo e(ucfirst($lead->occupancy_type)); ?>

                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not specified</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Client DOB:</div>
                                                <div class="col-md-7"><?php echo e($lead->eligibility_client_dob ? $lead->eligibility_client_dob->format('d/m/Y') : 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Possible Grant:</div>
                                                <div class="col-md-7"><?php echo e($lead->possible_grant_types ?? 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Benefit:</div>
                                                <div class="col-md-7"><?php echo e($lead->benefit_type ?? 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Proof of Address:</div>
                                                <div class="col-md-7"><?php echo e($lead->poa_info ?? 'Not specified'); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">EPC Rating:</div>
                                                <div class="col-md-7">
                                                    <?php if($lead->epc_rating): ?>
                                                        <span class="badge bg-<?php echo e($lead->epc_rating == 'A' ? 'success' : (
                                                            $lead->epc_rating == 'B' ? 'success' : (
                                                            $lead->epc_rating == 'C' ? 'info' : (
                                                            $lead->epc_rating == 'D' ? 'info' : (
                                                            $lead->epc_rating == 'E' ? 'warning' : 'danger'))))); ?>">
                                                            <?php echo e($lead->epc_rating); ?>

                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not specified</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">EPC Details:</div>
                                                <div class="col-md-7"><?php echo e($lead->epc_details ?? 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">GAS SAFE:</div>
                                                <div class="col-md-7"><?php echo e($lead->gas_safe_info ?? 'Not specified'); ?></div>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-md-5 fw-bold">Council Tax Band:</div>
                                                <div class="col-md-7">
                                                    <?php if($lead->council_tax_band): ?>
                                                        <span class="badge bg-secondary">Band <?php echo e($lead->council_tax_band); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">Not specified</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Activity Thread -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                    <span>Activity Thread</span>
                                    <div>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                                            <a href="<?php echo e(route('activities.create', $lead->id)); ?>" class="btn btn-sm btn-light">Add Activity</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <?php $__empty_1 = true; $__currentLoopData = $lead->activities->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="activity-item mb-4">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0">
                                                    <!-- User avatar or icon based on activity type -->
                                                    <div class="activity-avatar rounded-circle bg-<?php echo e($activity->type->value == 'note' ? 'primary' : ($activity->type->value == 'status_change' ? 'warning' : ($activity->type->value == 'file_upload' ? 'info' : 'secondary'))); ?>" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; color: white;">
                                                        <i class="fas <?php echo e($activity->type->value == 'note' ? 'fa-comment' : ($activity->type->value == 'status_change' ? 'fa-exchange-alt' : ($activity->type->value == 'file_upload' ? 'fa-file' : 'fa-tasks'))); ?>"></i>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1 ms-3">
                                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                                        <h6 class="mb-0">
                                                            <span class="fw-bold"><?php echo e($activity->user->name ?? 'System'); ?></span>
                                                            <small class="text-muted"><?php echo e($activity->type->name); ?></small>
                                                        </h6>
                                                        <small class="text-muted"><?php echo e($activity->created_at->format('M d, Y H:i')); ?></small>
                                                    </div>
                                                    <div class="activity-content p-3 bg-light rounded">
                                                        <p class="mb-1"><?php echo e($activity->description); ?></p>
                                                        <?php if($activity->message): ?>
                                                            <p class="mb-0 text-muted small"><?php echo e($activity->message); ?></p>
                                                        <?php endif; ?>
                                                        
                                                        <!-- Display documents attached to this activity -->
                                                        <?php if($activity->documents->count() > 0): ?>
                                                            <div class="mt-2 pt-2 border-top">
                                                                <p class="mb-1 small fw-bold">Attached Documents:</p>
                                                                <ul class="list-unstyled">
                                                                    <?php $__currentLoopData = $activity->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li class="small">
                                                                            <i class="fas fa-paperclip me-1"></i>
                                                                            <a href="<?php echo e(route('documents.download', $document->id)); ?>"><?php echo e($document->name); ?></a>
                                                                            <span class="text-muted">(<?php echo e(number_format($document->size_bytes / 1024, 2)); ?> KB)</span>
                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </ul>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="activity-actions mt-1">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                                                            <a href="<?php echo e(route('activities.edit', $activity->id)); ?>" class="btn btn-sm btn-link p-0">Edit</a> |
                                                            <a href="<?php echo e(route('documents.create.activity', ['lead' => $lead->id, 'activity' => $activity->id])); ?>" class="btn btn-sm btn-link p-0">Attach Document</a> |
                                                            <form method="POST" action="<?php echo e(route('activities.destroy', $activity->id)); ?>" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-sm btn-link text-danger p-0" onclick="return confirm('Are you sure?')">Delete</button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="text-center py-4">
                                            <p class="text-muted mb-0">No activity history found.</p>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Quick Add Activity Form -->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                                    <div class="mt-4 pt-3 border-top">
                                        <h6 class="mb-3">Add New Activity</h6>
                                        <form method="POST" action="<?php echo e(route('activities.store')); ?>" class="quick-activity-form">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
                                            
                                            <div class="row mb-3">
                                                <div class="col-md-4">
                                                    <select class="form-select form-select-sm <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type" required>
                                                        <option value="">Select Type</option>
                                                        <?php $__currentLoopData = \App\Enums\ActivityType::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activityType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($activityType->value); ?>">
                                                                <?php echo e($activityType->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control form-control-sm <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                        name="description" placeholder="Description" required>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <textarea class="form-control form-control-sm <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    name="message" rows="3" placeholder="Details (optional)"></textarea>
                                            </div>
                                            
                                            <div class="d-flex justify-content-end">
                                                <button type="submit" class="btn btn-sm btn-success">Add Activity</button>
                                            </div>
                                        </form>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Documents -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                                    <span>Documents</span>
                                    <div>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                                            <a href="<?php echo e(route('documents.create', $lead->id)); ?>" class="btn btn-sm btn-light">Add Document</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Kind</th>
                                                    <th>Size</th>
                                                    <th>Uploaded</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $lead->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($document->name); ?></td>
                                                        <td><?php echo e($document->kind->name); ?></td>
                                                        <td><?php echo e(number_format($document->size_bytes / 1024, 2)); ?> KB</td>
                                                        <td><?php echo e($document->created_at->format('M d, Y')); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('documents.download', $document->id)); ?>" class="btn btn-sm btn-primary">Download</a>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lead.edit')): ?>
                                                                <form method="POST" action="<?php echo e(route('documents.destroy', $document->id)); ?>" class="d-inline">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                                                </form>
                                                            <?php endif; ?>
                                                            <?php if($document->activity_id): ?>
                                                                <a href="<?php echo e(route('activities.edit', $document->activity_id)); ?>" class="btn btn-sm btn-info">View Activity</a>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center">No documents found.</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mamp\radiance\resources\views/leads/show.blade.php ENDPATH**/ ?>